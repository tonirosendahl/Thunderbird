make clean; make omnibusf4sd_bl ; st-flash write build/omnibusf4sd_bl/omnibusf4sd_bl.bin 0x8000000
